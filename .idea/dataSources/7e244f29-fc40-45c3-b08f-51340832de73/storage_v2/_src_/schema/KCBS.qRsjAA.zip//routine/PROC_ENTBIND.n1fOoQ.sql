create PROCEDURE proc_entbind
IS
BEGIN
   --1、刷新总公司及其以下分公司

   EXECUTE IMMEDIATE 'truncate table ts_entbind_companys';

   INSERT INTO ts_entbind_companys
      WITH mid1
              AS (    SELECT o.ent_id,
                             o.ent_name,
                             o.parent_id,
                             o.ent_type,
                             CONNECT_BY_ROOT (ent_id) root_id,
                             iscompany,
                             LEVEL lvl
                        FROM tb_organization o
                       WHERE o.enable_flag = '1' AND o.ent_state = '1'
                  START WITH o.iscompany = 1
                  CONNECT BY     PRIOR o.ent_id = o.parent_id
                             AND PRIOR o.enable_flag = '1'
                             AND PRIOR o.ent_state = '1'),
           mid2 AS               --过滤总公司异常值，如果一个企业的父节点和其本身都是总公司，数据会重复，以最上层节点为准
                  (  SELECT ent_id, MIN (lvl) lvl, COUNT (*) cnt
                       FROM mid1
                   GROUP BY ent_id
                     HAVING COUNT (*) > 1)
      SELECT a.ent_id,
             a.ent_name,
             parent_id,
             ent_type,
             root_id,
             iscompany
        FROM (SELECT * FROM mid1
              MINUS
              SELECT m1.*
                FROM mid1 m1, mid2 m2
               WHERE m1.ent_id = m2.ent_id AND m1.lvl = m2.lvl) a;

   COMMIT;
  -- DBMS_STATS.GATHER_TABLE_STATS ('KCPT', 'ts_entbind_companys');

   EXECUTE IMMEDIATE 'truncate table mid_entbind_conf_vehicle_all';

   EXECUTE IMMEDIATE 'truncate table mid_entbind_org';

   EXECUTE IMMEDIATE 'truncate table mid_entbind_vehicle';

   --1.1、刷新按规则绑定的车辆

   INSERT INTO mid_entbind_conf_vehicle_all
      SELECT o.ent_type,
             v.ent_id || '_' || c1.ent_id ent_id,
             v.ent_id ori_id,
             c1.ent_id leaf_id,
             t.company_id,
             v.vid,
             v.vehicle_no,
             v.plate_color,
             v.vbrand_code,
             v.origin_code
        FROM tb_vehicle v,
             tr_entbind_conf c1,
             tb_organization o,
             ts_entbind_companys t
       WHERE     v.vbrand_code = c1.bind_id
             AND c1.ent_id = o.ent_id
             AND c1.ent_id = t.ent_id
             AND c1.ent_id NOT IN (SELECT ent_id
                                     FROM tr_entbind_conf
                                    WHERE bind_type = '2') --规则2车辆来源可以不选，不选则以规则1车辆品牌为准
             AND c1.bind_type = '1'
             AND v.vehicle_state != 3
             AND v.enable_flag = '1'
      UNION
      SELECT o.ent_type,
             v.ent_id || '_' || c1.ent_id ent_id,
             v.ent_id ori_id,
             c1.ent_id leaf_id,
             t.company_id,
             v.vid,
             v.vehicle_no,
             v.plate_color,
             v.vbrand_code,
             v.origin_code
        FROM tb_vehicle v,
             tr_entbind_conf c1,
             tr_entbind_conf c2,
             tb_organization o,
             ts_entbind_companys t
       WHERE     v.vbrand_code = c1.bind_id
             AND v.origin_code = c2.bind_id
             AND c1.ent_id = o.ent_id
             AND c1.ent_id = t.ent_id
             AND c1.ent_id = c2.ent_id
             AND c1.bind_type = '1'
             AND c2.bind_type = '2'
             AND v.vehicle_state != 3
             AND v.enable_flag = '1';

   --COMMIT;
  -- DBMS_STATS.GATHER_TABLE_STATS ('KCPT', 'mid_entbind_conf_vehicle_all');

   --2.1、按车辆绑定——不包含按规则绑定

   --生成按车辆绑定的车辆（不包含规则）

   INSERT INTO mid_entbind_vehicle
      SELECT o.ent_type tree_type,
             v.ent_id || '_' || t.ent_id ent_id,
             v.ent_id ori_id,
             t.ent_id leaf_id,
             '',
             t.vid,
             v.vehicle_no,
             v.plate_color,
             v.vbrand_code,
             v.origin_code,
             '1' bind_type
        FROM tr_vehiclebind t, tb_vehicle v, tb_organization o
       WHERE t.vid = v.vid AND t.ent_id = o.ent_id
             AND t.ent_id NOT IN                                --不包含按规则绑定的多组织
                    (SELECT t.ent_id
                       FROM tr_entbind_conf c, ts_entbind_companys t
                      WHERE c.ent_id = t.company_id)
             AND o.enable_flag = '1'
             AND v.enable_flag = '1'
             AND o.ent_state = '1'
             AND v.vehicle_state != '3';

   INSERT INTO mid_entbind_org
      WITH vehiclebind_mid1
              AS                                      --查询出绑定车辆的多组织节点对应的企业组织节点
                (SELECT DISTINCT
                        leaf_id ent_id,
                        ori_ent_id binded_entid,
                        tree_type ent_type
                   FROM mid_entbind_vehicle),
           vehiclebind_mid2
              AS                                         --绑定的车辆所属组织向上递归至企业总公司
                (    SELECT DISTINCT
                            a.*,
                            CONNECT_BY_ROOT (ent_id) binded_entid,
                            CONNECT_BY_ISLEAF isleaf
                       FROM ts_entbind_companys a
                 START WITH a.ent_id IN
                               (SELECT binded_entid FROM vehiclebind_mid1)
                 CONNECT BY PRIOR a.parent_id = a.ent_id) --将绑定车辆所属的企业总公司节点挂接到绑定该车辆的多组织节点上
      SELECT DISTINCT
             v.ent_type tree_type,                        --该组织节点在多组织树中归属的组织类型
             o.ent_type,                                         --该组织节点的源组织类型
             o.ent_id || '_' || v.ent_id,
             o.ent_name,
             DECODE (o.isleaf,
                     1, v.ent_id,
                     0, o.parent_id || '_' || v.ent_id,
                     o.parent_id || '_' || v.ent_id)
                parent_id,                        --将绑定车辆的企业树的总公司节点挂到多组织树的叶子节点
             v.ent_id leaf_id,
             o.ent_id ori_ent_id,
             '1' bind_type
        FROM vehiclebind_mid1 v, vehiclebind_mid2 o
       WHERE v.binded_entid = o.binded_entid;

   --2.2、按车辆绑定——按规则绑定
   --生成按车辆绑定的车辆（按规则过滤）

   INSERT INTO mid_entbind_vehicle
      SELECT o.ent_type tree_type,
             v.ent_id || '_' || t.ent_id ent_id,
             v.ent_id ori_id,
             t.ent_id leaf_id,
             s.company_id,
             v.vid,
             v.vehicle_no,
             v.plate_color,
             v.vbrand_code,
             v.origin_code,
             '2' bind_type
        FROM tr_vehiclebind t,
             tb_vehicle v,
             tb_organization o,
             ts_entbind_companys s,
             mid_entbind_conf_vehicle_all m
       WHERE     t.vid = v.vid
             AND t.ent_id = o.ent_id
             AND t.ent_id = s.ent_id
             AND t.vid = m.vid                                 --关联多组织总公司设置的规则
             AND s.company_id = m.company_id;

   INSERT INTO mid_entbind_org
      WITH vehiclebind_mid1
              AS (SELECT DISTINCT
                         leaf_id ent_id, ori_ent_id binded_entid, tree_type
                    FROM mid_entbind_vehicle
                   WHERE bind_type = '2'),
           vehiclebind_mid2
              AS                                         --绑定的车辆所属组织向上递归至企业总公司
                (    SELECT DISTINCT
                            a.*,
                            CONNECT_BY_ROOT (ent_id) binded_entid,
                            CONNECT_BY_ISLEAF isleaf
                       FROM ts_entbind_companys a
                 START WITH a.ent_id IN
                               (SELECT binded_entid FROM vehiclebind_mid1)
                 CONNECT BY PRIOR a.parent_id = a.ent_id) --将绑定车辆所属的企业总公司节点挂接到绑定该车辆的多组织节点上
      SELECT DISTINCT
             v.tree_type tree_type,                       --该组织节点在多组织树中归属的组织类型
             o.ent_type,                                         --该组织节点的源组织类型
             o.ent_id || '_' || v.ent_id,
             o.ent_name,
             DECODE (o.isleaf,
                     1, v.ent_id,
                     0, o.parent_id || '_' || v.ent_id,
                     o.parent_id || '_' || v.ent_id)
                parent_id,                        --将绑定车辆的企业树的总公司节点挂到多组织树的叶子节点
             v.ent_id leaf_id,
             o.ent_id ori_ent_id,
             '2' bind_type
        FROM vehiclebind_mid1 v, vehiclebind_mid2 o
       WHERE v.binded_entid = o.binded_entid;

   --3.1、按组织绑定——不包含按规则绑定

   --insert into mid_entbind_vehicle

   INSERT INTO mid_entbind_vehicle
      SELECT                                                /*+ use_hash(O) */
            o.ent_type tree_type,                         --该组织节点在多组织树中归属的组织类型
             a.ent_id || '_' || t.ent_id,
             a.ent_id,
             t.ent_id leaf_id,
             '',
             v.vid,
             v.vehicle_no,
             v.plate_color,
             v.vbrand_code,
             v.origin_code,
             '3'
        FROM tb_vehicle v,
             tr_entbind t,
             ts_entbind_companys a,
             tb_organization o
       WHERE     v.ent_id = a.ent_id
             AND t.bindedentid = a.company_id
             AND t.ent_id = o.ent_id
             AND t.bindtype = 1
             AND v.vehicle_state != 3
             AND v.enable_flag = '1'
             AND t.ent_id NOT IN
                    (SELECT b.ent_id
                       FROM TS_ENTBIND_COMPANYS B, TR_ENTBIND_CONF C
                      WHERE B.COMPANY_ID = C.ENT_ID);


   INSERT INTO mid_entbind_org
      SELECT DISTINCT
             o.ent_type tree_type,                        --该组织节点在多组织树中归属的组织类型
             a.ent_type,                                         --该组织节点的源组织类型
             a.ent_id || '_' || t.ent_id,
             a.ent_name,
             DECODE (a.ent_id,
                     t.bindedentid, t.ent_id,
                     a.parent_id || '_' || t.ent_id)
                parent_id,                        --将绑定企业的企业树的总公司节点挂到多组织树的叶子节点
             t.ent_id leaf_id,
             a.ent_id ori_ent_id,
             '3' bind_type
        FROM ts_entbind_companys a, tr_entbind t, tb_organization o
       WHERE a.company_id = t.bindedentid AND t.ent_id = o.ent_id
             AND t.ent_id NOT IN                                --不包含按规则绑定的多组织
                    (SELECT t.ent_id
                       FROM tr_entbind_conf c, ts_entbind_companys t
                      WHERE c.ent_id = t.company_id)
             AND t.bindtype = 1;

   --3.2、按组织绑定——包含按规则绑定
   --生成按组织绑定的车辆（按规则过滤）

   INSERT INTO mid_entbind_vehicle
      SELECT                                                  /*+use_hash(o)*/
            o.ent_type tree_type,
             v.ent_id || '_' || t.ent_id ent_id,
             v.ent_id ori_id,
             t.ent_id leaf_id,
             s2.company_id,
             v.vid,
             v.vehicle_no,
             v.plate_color,
             v.vbrand_code,
             v.origin_code,
             '4' bind_type
        FROM tr_entbind t,
             ts_entbind_companys s1,                                      --企业
             ts_entbind_companys s2,                                     --多组织
             tb_vehicle v,
             tb_organization o,
             mid_entbind_conf_vehicle_all m
       WHERE     t.bindedentid = s1.company_id
             AND t.ent_id = s2.ent_id
             AND s1.ent_id = v.ent_id
             AND t.ent_id = o.ent_id
             AND v.vid = m.vid
             AND s2.company_id = m.company_id
             AND t.bindtype = 1;

   INSERT INTO mid_entbind_org
      WITH entbind_mid1
              AS (SELECT DISTINCT leaf_id, ori_ent_id binded_entid, tree_type
                    FROM mid_entbind_vehicle
                   WHERE bind_type = '4'),
           entbind_mid2
              AS (    SELECT DISTINCT
                             a.*,
                             CONNECT_BY_ROOT (a.ent_id) binded_entid,
                             CONNECT_BY_ISLEAF isleaf
                        FROM ts_entbind_companys a
                  START WITH a.ent_id IN
                                (SELECT binded_entid FROM entbind_mid1)
                  CONNECT BY PRIOR a.parent_id = a.ent_id)
      SELECT DISTINCT
             v.tree_type,                                 --该组织节点在多组织树中归属的组织类型
             o.ent_type,                                         --该组织节点的源组织类型
             o.ent_id || '_' || v.leaf_id,
             o.ent_name,
             DECODE (o.isleaf,
                     1, v.leaf_id,
                     0, o.parent_id || '_' || v.leaf_id,
                     o.parent_id || '_' || v.leaf_id)
                parent_id,                        --将绑定车辆的企业树的总公司节点挂到多组织树的叶子节点
             v.leaf_id,
             o.ent_id ori_ent_id,
             '4' bind_type
        FROM entbind_mid1 v, entbind_mid2 o
       WHERE v.binded_entid = o.binded_entid;

   --4、按规则绑定
   INSERT INTO mid_entbind_vehicle
      SELECT t.*, '5'
        FROM mid_entbind_conf_vehicle_all t,
             (SELECT t.tree_type, t.company_id, t.vid
                FROM mid_entbind_conf_vehicle_all t
              MINUS                                          --去掉多组织分公司已经分配的车辆
              SELECT m.tree_type, m.company_id, m.vid
                FROM mid_entbind_vehicle m
               WHERE m.bind_type IN ('2', '4')) a
       WHERE     t.tree_type = a.tree_type
             AND t.company_id = a.company_id
             AND t.vid = a.vid;

   INSERT INTO mid_entbind_org
      WITH entbind_mid1
              AS (SELECT DISTINCT leaf_id, ori_ent_id binded_entid, tree_type
                    FROM mid_entbind_vehicle
                   WHERE bind_type = '5'),
           entbind_mid2
              AS (    SELECT DISTINCT
                             a.*,
                             CONNECT_BY_ROOT (a.ent_id) binded_entid,
                             CONNECT_BY_ISLEAF isleaf
                        FROM ts_entbind_companys a
                  START WITH a.ent_id IN
                                (SELECT binded_entid FROM entbind_mid1)
                  CONNECT BY PRIOR a.parent_id = a.ent_id)
      SELECT DISTINCT
             v.tree_type,                                 --该组织节点在多组织树中归属的组织类型
             o.ent_type,                                         --该组织节点的源组织类型
             o.ent_id || '_' || v.leaf_id,
             o.ent_name,
             DECODE (o.isleaf,
                     1, v.leaf_id,
                     0, o.parent_id || '_' || v.leaf_id,
                     o.parent_id || '_' || v.leaf_id)
                parent_id,                        --将绑定车辆的企业树的总公司节点挂到多组织树的叶子节点
             v.leaf_id,
             o.ent_id ori_ent_id,
             '5' bind_type
        FROM entbind_mid1 v, entbind_mid2 o
       WHERE v.binded_entid = o.binded_entid;

   --5、多组织本身组织
   INSERT INTO mid_entbind_org
      SELECT t.ent_type tree_type,
             t.ent_type ent_type,                                --该组织节点的源组织类型
             t.ent_id,
             t.ent_name,
             t.parent_id parent_id,
             '' leaf_id,
             t.ent_id ori_ent_id,
             '6'
        FROM tb_organization t
       WHERE     t.enable_flag = '1'
             AND t.ent_state = '1'
             AND t.ent_type NOT IN (1, 2, 3);

  -- COMMIT;

 --  DBMS_STATS.GATHER_TABLE_STATS ('KCPT', 'mid_entbind_org');

   --6、更新多组织结果表

   delete from mv_organization;

   INSERT INTO mv_organization
      SELECT tree_type,
             ent_type,
             t.ent_id,
             ori_ent_id,
             ent_name,
             parent_id,
             i.org_shortname,
             i.corp_code,
             CASE WHEN t.ent_type > 3 THEN '1' ELSE i.corp_level END
                corp_level,                   --corp_level不为空页面显示企业图标，否则显示车辆图标
             i.isdeteam,
             i.org_logo,
             sys_guid() as id
        FROM mid_entbind_org t, tb_org_info i
       WHERE t.ori_ent_id = i.ent_id;

   delete from mv_vehicle;

   INSERT INTO mv_vehicle
      WITH ent_paths
              AS (    SELECT o.ent_id,
                             o.ent_type,
                             SYS_CONNECT_BY_PATH (o.ent_id, '#') || '#' tree_path
                        FROM tb_organization o
                       WHERE o.enable_flag = '1' AND o.ent_state = '1'
                  START WITH o.parent_id = '-1'
                             AND o.ent_type NOT IN (1, 2, 3)
                  CONNECT BY     PRIOR o.ent_id = o.parent_id
                             AND PRIOR o.ent_type = o.ent_type
                             AND PRIOR o.enable_flag = '1'
                             AND PRIOR o.ent_state = '1')
      SELECT DISTINCT tree_type,
                      v.ent_id,
                      ori_ent_id,
                      leaf_id,
                      v.vid,
                      vehicle_no,
                      plate_color,
                      vbrand_code,
                      origin_code,
                      a.tree_path,
                      s.sid,
                      s.commaddr,
                      t.tid,
                      t.tmac,
                      sys_guid() as id
        FROM mid_entbind_vehicle v,
             ent_paths a,
             tr_serviceunit r,
             tb_sim s,
             tb_terminal t
       WHERE     v.leaf_id = a.ent_id
             AND v.vid = r.vid
             AND r.sid = s.sid
             AND r.tid = t.tid;

   COMMIT;
--io_return := 1;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
--io_return := sqlcode;
END proc_entbind;
/

