create FUNCTION "FUN_DATE2UTC" (p_date IN DATE)
   RETURN NUMBER
IS
   utc   NUMBER;
/**
* 根据日期获得utc值
*/
BEGIN
   utc :=
        86400
      * 1000
      * (p_date - TO_DATE ('1970/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:ss'))
      - (8 * 1000 * 3600);
   RETURN utc;
END fun_date2utc;
/

