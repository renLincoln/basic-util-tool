create function fun_getVehicleDispatchNum(orderId in varchar2)
return varchar2 is str varchar2(50);
begin
  for r in (select t.vehicle_code from Ly_Vehicle_Dispatch t where t.order_id = orderId )
      loop
        str := str || r.vehicle_code || ',';
      end loop;
      str:= substr(str,0,length(str)-1);
  return (str);
end fun_getVehicleDispatchNum;
/

