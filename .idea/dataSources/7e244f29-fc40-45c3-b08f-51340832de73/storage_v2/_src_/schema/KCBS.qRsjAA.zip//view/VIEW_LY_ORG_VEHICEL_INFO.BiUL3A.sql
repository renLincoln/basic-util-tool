create view VIEW_LY_ORG_VEHICEL_INFO as
  SELECT    T1.VID as VEHICLE_ID,
          T4.PARENT_ID,
          T6.ENT_NAME AS PARENT_NAME,
          T4.ENT_ID,
          T4.ENT_NAME,
    T1.VEHICLE_NO,
    T1.VBRAND_CODE,
    (select code_name from sys_general_code t where t.general_code=T1.VBRAND_CODE and t.enable_flag=1 and t.parent_general_code='SYS_VEHICLE_BRAND') BRAND,
    T1.PROD_CODE,
          T3.PROD_NAME,
          T1.Vehicle_Mennum as MAXIMAL_PEOPLE,
    T5.MAPLON/600000 as MAPLON,
    T5.MAPLAT/600000 as MAPLAT,
   (SELECT E.STAFF_ID||';'||E.STAFF_NAME||';'||E.MOBILEPHONE
          FROM TB_EMPLOYEE E,TR_VEHICLE_STAFF S WHERE E.STAFF_ID=S.STAFF_ID AND S.VID=T1.VID AND ROWNUM=1
          ) AS DRIVER_INFO
       FROM   TB_VEHICLE T1,
              SYS_PRODUCT_TYPE T3,
              TB_ORGANIZATION T4,
              TR_VEHICLE_LASTTRACK T5,
              TB_ORGANIZATION T6
       WHERE  T1.ENABLE_FLAG=1
            AND T1.VEHICLE_OPERATION_STATE IN(10,35)
             AND T1.ENT_ID=T4.ENT_ID
            AND T1.VID=T5.VID(+)
            AND T1.PROD_CODE=T3.PROD_CODE(+)
            AND T4.PARENT_ID=T6.ENT_ID
/

