create PACKAGE BODY "GRADE_SCORE_PACK"
IS
   ---------用于计算得分 标准100~0分情况 基本算法
   FUNCTION count_base_score (in_sum_num        NUMBER,              --违规数据统计值
                              in_mileage_sum    NUMBER,              --行车里程统计值
                              in_fazhi_100      NUMBER,               --100分阀值
                              in_fazhi_0        NUMBER)                 --0分阀值
      RETURN NUMBER
   AS
      re_num   NUMBER := 0;                                              --返回值
      v_num    NUMBER;                                                --实际计算后值
   BEGIN
      IF in_mileage_sum <= 0 OR in_mileage_sum IS NULL
      THEN
         --行车里程0则得0分
         re_num := 0;
      ELSIF in_sum_num = 0 OR in_sum_num IS NULL
      THEN
         --无违规次数则得100分
         re_num := 100;
      ELSIF in_sum_num > 0 AND in_fazhi_100 = 0 AND in_fazhi_0 = 1
      THEN
         --阀值为0~1，则有疲劳即为0分
         re_num := 0;
      ELSE
         --每1000公里平均数据
         v_num := in_sum_num * 1000 / in_mileage_sum;

         IF v_num >= in_fazhi_0
         THEN
            --大于等于0分阀值得0分
            re_num := 0;
         ELSIF v_num <= in_fazhi_100
         THEN
            --小于等于100分阀值得100分
            re_num := 100;
         ELSE
            --正常计算，消耗最高, floor取整
            re_num :=
               ROUND (
                  100
                  -   (v_num - in_fazhi_100)
                    * 100
                    / (in_fazhi_0 - in_fazhi_100),
                  2);
         END IF;
      END IF;

      RETURN re_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN re_num;
   END;

   ---------用于计算平均分 基本算法
   FUNCTION count_average_score (in_sum_num NUMBER,                       --总分
                                                   in_count NUMBER)       --个数
      RETURN NUMBER
   AS
      re_num   NUMBER := 0;                                              --返回值
   BEGIN
      IF in_sum_num = 0 OR in_sum_num IS NULL
      THEN
         --总分0则得0分
         re_num := 0;
      ELSE
         re_num := ROUND (in_sum_num / in_count, 2);
      END IF;

      RETURN re_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN re_num;
   END;

   ---------用于计算实际百公里油耗值【也可计算考核百公里油耗值】
   FUNCTION count_factoilwear_value (in_oilwear_sum    NUMBER,      --实际燃油消耗总值
                                     in_mileage_sum    NUMBER)       --行车里程统计值
      RETURN NUMBER
   AS
      re_num   NUMBER := 0;                                              --返回值
   BEGIN
      IF in_oilwear_sum IS NULL OR in_mileage_sum IS NULL
      THEN
         RETURN re_num;
      END IF;

      IF in_mileage_sum <= 0
      THEN
         re_num := ROUND (in_oilwear_sum, 2);
      ELSE
         re_num := ROUND (in_oilwear_sum * 100 / in_mileage_sum, 2);
      END IF;

      RETURN re_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN re_num;
   END;

   ---------用户计算节油量
   FUNCTION count_saveoil_value (in_checkoil_sum       NUMBER,      --考核百公里油耗值
                                 in_mileage_sum        NUMBER,        --行驶总里程值
                                 in_factoilwear_sum    NUMBER)         --实际总油耗
      RETURN NUMBER
   AS
      re_num   NUMBER := 0;                                              --返回值
   BEGIN
      IF in_checkoil_sum <= 0 OR in_checkoil_sum IS NULL
      THEN
         re_num := 0;
      ELSE
         re_num :=
            ROUND (
               in_checkoil_sum * in_mileage_sum / 100 - in_factoilwear_sum,
               2);
      END IF;

      RETURN re_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN re_num;
   END;

   ---------用于计算百公里节油率
   FUNCTION count_saveoil_ratio (in_checkoilwear       NUMBER,      --考核百公里油耗值
                                 in_mileage_sum        NUMBER,        --行驶总里程值
                                 in_factoilwear_sum    NUMBER)         --实际总油耗
      RETURN NUMBER
   AS
      re_num          NUMBER := 0;                                       --返回值
      v_saveoil_100   NUMBER;                                         --百公里节油量
   BEGIN
      IF in_checkoilwear <= 0 OR in_checkoilwear IS NULL
      THEN
         re_num := 0;
      ELSE
         --计算百公里节油量  节油量/行驶总里程 *100
         v_saveoil_100 :=
            count_saveoil_value (in_checkoilwear,
                                 in_mileage_sum,
                                 in_factoilwear_sum)
            * 100
            / in_factoilwear_sum;

         IF v_saveoil_100 <= 0 OR v_saveoil_100 IS NULL
         THEN
            re_num := 0;
         ELSE
            re_num := ROUND (v_saveoil_100 * 100 / in_checkoilwear, 2);
         END IF;
      END IF;

      RETURN re_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN re_num;
   END;

   ---------用于计算油耗考核得分
   FUNCTION count_checkoilwear_score (in_factoilwear     NUMBER,     --本月实际总油耗
                                      in_mileage_sum     NUMBER,     --行车实际总里程
                                      in_checkoilwear    NUMBER)     --本月油耗考核值
      RETURN NUMBER
   AS
      re_num           NUMBER := 0;                                      --返回值
      temp_0           NUMBER := 0;                                   --考核1.5倍
      temp_200         NUMBER := 0;                                   --考核0.5倍
      v_factoillwear   NUMBER;                                       --实际百公里油耗
   BEGIN
      IF in_factoilwear <= 0 OR in_factoilwear IS NULL
      THEN
         re_num := 0;
      ELSIF in_checkoilwear <= 0 OR in_checkoilwear IS NULL
      THEN
         re_num := 0;
      ELSE
         temp_0 := 1.5 * in_checkoilwear;
         temp_200 := 0.5 * in_checkoilwear;

         --换算成实际百公里油耗
         v_factoillwear := in_factoilwear * 100 / in_mileage_sum;

         IF v_factoillwear >= temp_0
         THEN
            re_num := 0;
         ELSIF v_factoillwear <= temp_200
         THEN
            re_num := 200;
         ELSE
            re_num :=
               ROUND (
                  100
                  +   (in_checkoilwear - v_factoillwear)
                    * 100
                    / (temp_0 - in_checkoilwear),
                  2);
         END IF;
      END IF;

      RETURN re_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN re_num;
   END;

   ---------用于计算油耗考核实际得分
   FUNCTION count_checkoilwear_score_real (in_factoilwear     NUMBER, --本月实际总油耗
                                           in_mileage_sum     NUMBER, --行车实际总里程
                                           in_checkoilwear    NUMBER, --本月油耗考核值
                                           oilwearchk_min     NUMBER, --考核油耗系数小值 百分数
                                           oilwearchk_max     NUMBER) --考核油耗系数大值 百分数
      RETURN NUMBER
   AS
      re_num           NUMBER := 0;                                      --返回值
      temp_0           NUMBER := 0;                                   --考核油耗大值
      temp_200         NUMBER := 0;                                   --考核油耗小值
      v_factoillwear   NUMBER;                                       --实际百公里油耗
   BEGIN
      IF in_factoilwear <= 0 OR in_factoilwear IS NULL
      THEN
         re_num := 0;
      ELSIF in_checkoilwear <= 0 OR in_checkoilwear IS NULL
      THEN
         re_num := 0;
      ELSE
         --temp_0   := (oilwearchk_max/100) * in_checkoilwear + in_checkoilwear;
         --temp_200 := (oilwearchk_min/100) * in_checkoilwear + in_checkoilwear;
         --yujch 20140521 调整 油耗得分计算规则调整
         temp_0 := oilwearchk_max + in_checkoilwear;
         temp_200 := oilwearchk_min + in_checkoilwear;

         --换算成实际百公里油耗
         v_factoillwear := in_factoilwear * 100 / in_mileage_sum;

         IF v_factoillwear >= temp_0
         THEN
            re_num := 0;
         ELSIF v_factoillwear <= temp_200
         THEN
            re_num := 100;
         ELSE
            --公式：floor(（0分阀值-实际百公里油耗）*100/(0分阀值-100分阀值))
            re_num :=
               ROUND ( (temp_0 - v_factoillwear) * 100 / (temp_0 - temp_200),
                      2);
         END IF;
      END IF;

      RETURN re_num;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN re_num;
   END;
END grade_score_pack;
/

