create view VIEW_SIM as
  SELECT po.ent_id AS pent_id,
            po.ENT_NAME AS pent_name,
            po.ENT_STATE,
            poi.CORP_BUSINESSNO,
            poi.SPECIAL_ID,
            poi.BUSINESS_SCOPE,
            poi.CERTIFICATE_OFFICE,
            poi.LICENCE_NO,
            poi.CORP_QUALE,
            poi.CORP_BOSS,
            poi.CORP_PAYSTATE,
            poi.CORP_PAYTYPE,
            poi.CORP_ECONOMYTYPE,
            poi.ORG_ADDRESS,
            poi.ORG_CZIP,
            poi.ORG_CFAX,
            poi.URL,
            poi.ORG_CMAIL,
            poi.ORG_CNAME,
            poi.CREATE_UTC,
            poi.ORG_LOGO,
            poi.ORG_MEM,
            poi.ORG_CPHONE,
            poi.CORP_COUNTRY,
            poi.CORP_PROVINCE,
            poi.CORP_CITY,
            poi.CORP_LEVEL,
            poi.ORG_SHORTNAME AS piORG_SHORTNAME,
            poi.CORP_CODE,
            o.ent_id,
            o.ENT_NAME,
            o.ENT_TYPE,
            oi.ORG_SHORTNAME,
            oi.ISDETEAM,
            s.SID,
            s.COMMADDR,
            s.PASSWORD,
            s.ICCID_ELECTRON,
            s.BUSINESS_ID,
            s.COMBO_ID,
            (SELECT uc.combo_name
               FROM sys_unit_combo uc
              WHERE uc.combo_id = s.combo_id)
               AS combo_name,
            s.SVC_START,
            s.SVC_STOP,
            s.SUDESC,
            s.PROVINCE,
            s.SIM_STATE,
            s.ICCID_PRINT,
            s.IMSI,
            s.APN,
            s.PIN,
            s.PUK,
            s.CITY,
            s.create_by,
            (SELECT so.op_name
               FROM sys_sp_operator so
              WHERE s.create_by = so.op_id)
               AS op_name,
            s.create_time,
            s.update_by,
            s.update_time,
            (SELECT so.op_name
               FROM sys_sp_operator so
              WHERE s.update_by = so.op_id)
               AS update_name
       -- 企业 (po) 企业信息 parentId (poi), 车队 (o) 车队信息 (oi), SIM卡 (s)
       FROM tb_organization po
            JOIN tb_org_info poi
               ON (po.ent_id = poi.ent_id)
            JOIN tb_organization o
               ON (po.ent_id = o.parent_id)
            JOIN tb_org_info oi
               ON (o.ent_id = oi.ent_id)
            JOIN tb_sim s
               ON (oi.ent_id = s.ent_id)
      WHERE s.enable_flag = '1'
   ORDER BY s.update_time DESC
/

