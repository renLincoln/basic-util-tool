create FUNCTION "FUN_SECOND2TIME" (p_seconds IN NUMBER)
   RETURN VARCHAR2
IS
   p_time     VARCHAR2 (32);
   p_hour     VARCHAR2 (32);
   p_minute   VARCHAR2 (32);
   p_second   VARCHAR2 (32);
BEGIN
   p_hour := LPAD (TRUNC (p_seconds / 3600), 2, '0');
   p_minute := LPAD (TRUNC ( (p_seconds - p_hour * 3600) / 60), 2, '0');
   p_second := LPAD (p_seconds - p_hour * 3600 - p_minute * 60, 2, '0');
   p_time := p_hour || ':' || p_minute || ':' || p_second;
   RETURN p_time;
END fun_second2time;
/

