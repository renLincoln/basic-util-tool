create FUNCTION "FUN_GET_COLUMN" (CID IN VARCHAR2)
   RETURN VARCHAR2
IS
   --RLINE   VARCHAR2(2000) := 'wrong';
   V_STR     VARCHAR2 (2000) := '';
   V_START   VARCHAR2 (20) := '[';
   V_END     VARCHAR2 (20) := ']';
BEGIN
   IF CID IS NULL
   THEN
      RETURN 'wrong';
   END IF;

   FOR I IN (SELECT T.POI_SERVICEBRAND, T.POI_SERVICELEVEL
               FROM TB_SERVICES_POI_SCOPE T
              WHERE T.POI_ID = CID)
   LOOP
      V_STR :=
            V_STR
         || '{'''
         || NVL (I.POI_SERVICEBRAND, ' ')
         || ''':'''
         || NVL (I.POI_SERVICELEVEL, ' ')
         || '''},';
   END LOOP;

   IF INSTR (V_STR, ',') > 0
   THEN
      V_STR := SUBSTR (V_STR, 0, LENGTH (V_STR) - 1);
   END IF;

   V_STR := V_START || V_STR || V_END;
   RETURN (V_STR);
END FUN_GET_COLUMN;
/

