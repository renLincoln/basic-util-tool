create view VIEW_VEHICLE_INFO as
  SELECT po.ent_id AS pent_id,
          po.ent_name AS pent_name,
          poi.corp_province,
          poi.CORP_CITY,
          poi.certificate_office,
          poi.business_scope,
          poi.licence_no,
          poi.org_cphone,
          poi.corp_boss,
          poi.org_address,
          o.ent_name,
          oi.org_cname,
          o.ent_id,
          pt.prod_name prod_name,                                         --车型
          v.vid,
          v.vehicle_no,
          v.plate_color,
          v.vtype_id,
          v.prod_code,
          v.vbrand_code,
          v.inner_code,
          v.first_instal_time,
          v.release_date,
          v.watt,
          v.curb_weight,
          v.wheelbase,
          prog.prog_name prog_name,
          br.SERVICEBRAND_LOGO SERVICEBRAND_LOGO,
          -- 道路运输许可证 v.ROAD_TRANSPORT,
          v.vehicle_type,
          v.vin_code,
          v.ebrand_code,
          v.emodel_code,
          v.vehicle_state,
          v.update_time,
          s.commaddr,
          --终端厂商，                                    通信协议
          t.tmac,
          t.oem_code,
          sto.full_name,
          t.tmodel_code,
          t.tprotocol_id,
          ttp.tprotocol_name,
          STAFF.staff_name AS staff_name,
          v.vehicle_operation_state
     -- 企业 po，企业信息 poi，车队 o， 车队信息 oi，车辆 v
     FROM TB_ORGANIZATION po
          JOIN TB_ORG_INFO poi
             ON (po.ent_id = poi.ent_id)
          JOIN TB_ORGANIZATION o
             ON (o.parent_id = poi.ent_id AND o.enable_flag != 0)
          JOIN TB_ORG_INFO oi
             ON (oi.ent_id = o.ent_id)
          JOIN TB_VEHICLE V
             ON (v.ent_id = oi.ent_id AND v.enable_flag = '1')
          -- 车、卡终端关系 su，卡 s，终端 t
          LEFT JOIN TR_SERVICEUNIT su
             ON (v.vid = su.vid)
          LEFT JOIN TB_SIM S
             ON (su.sid = s.sid)
          LEFT JOIN TB_TERMINAL T
             ON (su.tid = t.tid)
          -- 终端厂商 tb_terminal_protocol ttp, 终端协议 sys_terminal_oem sto
          LEFT JOIN tb_terminal_protocol ttp
             ON (ttp.tprotocol_id = t.tprotocol_id)
          LEFT JOIN sys_terminal_oem sto
             ON (sto.oem_code = t.oem_code)
          LEFT JOIN sys_product_type pt
             ON     v.prod_code = pt.prod_code
                AND v.vbrand_code = pt.vbrand_code
                AND pt.enable_flag = '1'
          LEFT JOIN tb_vehicle_configuer_programme prog
             ON v.prog_id = prog.prog_id
          LEFT JOIN SYS_SERVICE_BRAND br
             ON br.SERVICEBRAND_CODE = V.SERVICEBRAND_CODE
          LEFT JOIN (  SELECT SF.VID, WM_CONCAT (EP.STAFF_NAME) STAFF_NAME
                         FROM TB_EMPLOYEE EP, TR_VEHICLE_STAFF SF
                        WHERE EP.STAFF_ID = SF.STAFF_ID
                     GROUP BY SF.VID) STAFF
             ON v.vid = STAFF.vid
/

