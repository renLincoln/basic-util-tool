create FUNCTION "FUN_UTC2DATE" (p_utc IN NUMBER)
   RETURN DATE
IS
   p_date   DATE;
/**
*      -- name: utc2date
-- return: date
-- param: p_utc [in] NUMBER: UTC(s)
*/
BEGIN
   p_date :=
      TO_DATE ('1970/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:ss')
      + ( (p_utc + 8 * 1000 * 3600) / 1000) / 86400;
   RETURN p_date;
END fun_utc2date;
/

