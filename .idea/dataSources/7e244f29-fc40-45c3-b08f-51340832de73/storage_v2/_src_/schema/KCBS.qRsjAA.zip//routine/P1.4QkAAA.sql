create procedure p1 is
  INS_SQL  VARCHAR2(3000);
  ADD_START_DAY VARCHAR2(20);
  START_DAY_DATE1 VARCHAR2(40);
  START_DAY_DATE date;
  END_DAY_DATE date;
  START_DAY_UTC number;
  END_DAY_UTC number;
  v_2 int;
begin
  START_DAY_DATE :=to_date('2017-07-01 00:00:00','yyyy-mm-dd hh24:mi:ss');
  START_DAY_UTC := fun_date2utc(to_date('2017-07-01 00:00:00','yyyy-mm-dd hh24:mi:ss'));
  END_DAY_UTC := fun_date2utc(to_date('2018-04-01 00:00:00','yyyy-mm-dd hh24:mi:ss'));
  END_DAY_DATE :=to_date('2018-04-01 00:00:00','yyyy-mm-dd hh24:mi:ss');
  select months_between(END_DAY_DATE, START_DAY_DATE) into v_2 from dual; 
  START_DAY_DATE1  := to_char(START_DAY_DATE,'yyyy-mm-dd hh24:mi:ss');
  END_DAY_UTC := fun_date2utc(add_months(to_date('2017-07-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),1));
  FOR i in 1..v_2+1
     LOOP
     --ADD_SQL:= 'insert into td_time select sys_guid() ,''c30db8c4211540c3aece140e50a23b7a'', ''' || ADD_START_DAY || ''', ''day'';' ;
     INS_SQL:= 'insert into BAK_TEST_0608 SELECT 
  t_org.ent_name  ,
  vv.op_loginname  ,
  vv.num,''' || START_DAY_DATE1 || '''
FROM
  TEMP_ORG t_org
LEFT JOIN (
  SELECT
    corp_name,
    SYS.op_loginname,
    COUNT (1) num
  FROM
    (
      SELECT
        org.ent_id team_id,
        CONNECT_BY_ROOT org.ent_name corp_name
      FROM
        tb_organization org
      WHERE
        org.enable_flag = ''1'' START WITH ent_name IN (SELECT ent_name FROM TEMP_ORG) CONNECT BY PRIOR ent_id = parent_id
    ) ent,
    TL_OPERATE_LOG tg,
    SYS_SP_OPERATOR sys
  WHERE
    ent.team_id = tg.ent_id
  AND tg.op_id = SYS.op_id (+)
  AND tg.log_utc >= ' || START_DAY_UTC ||'
  AND tg.log_utc < ' || END_DAY_UTC || '
  and tg.LOG_TYPEID = ''USERLOGIN''
  GROUP BY
    corp_name,
    SYS.op_loginname
) vv ON t_org.ent_name = vv.corp_name';
    BEGIN
         EXECUTE IMMEDIATE INS_SQL;
         commit;
         sys.DBMS_LOCK.sleep(5);           
    END;  
     --(add_months(to_date(ADD_START_MONTH,'yyyymm'),1),'yyyymm');
     START_DAY_UTC := fun_date2utc(add_months(to_date('2017-07-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),i));
     END_DAY_UTC := fun_date2utc(add_months(to_date('2017-07-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),i+1));
     START_DAY_DATE := add_months(to_date('2017-07-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),i);
     START_DAY_DATE1  := to_char(START_DAY_DATE,'yyyy-mm-dd hh24:mi:ss');
     --START_DAY:=  ((to_date(ADD_START_DAY,'yyyy-mm-dd')+1),'yyyy-mm-dd');
     --END_DAY:=  ((to_date(ADD_START_DAY,'yyyy-mm-dd')+1),'yyyy-mm-dd');
     dbms_output.put_line(INS_SQL);
    end loop;
end;
/

