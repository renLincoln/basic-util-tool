create procedure p2 is
  INS_SQL  VARCHAR2(3000);
  ADD_START_DAY VARCHAR2(20);
  START_DAY_DATE1 VARCHAR2(40);
  START_DAY_DATE date;
  END_DAY_DATE date;
  START_DAY_UTC number;
  END_DAY_UTC number;
  v_2 int;
begin
  START_DAY_DATE :=to_date('2017-01-01 00:00:00','yyyy-mm-dd hh24:mi:ss');
  START_DAY_UTC := fun_date2utc(to_date('2017-01-01 00:00:00','yyyy-mm-dd hh24:mi:ss'));
  END_DAY_UTC := fun_date2utc(to_date('2017-06-01 00:00:00','yyyy-mm-dd hh24:mi:ss'));
  END_DAY_DATE :=to_date('2017-06-01 00:00:00','yyyy-mm-dd hh24:mi:ss');
  select months_between(END_DAY_DATE, START_DAY_DATE) into v_2 from dual; 
  START_DAY_DATE1  := to_char(START_DAY_DATE,'yyyy-mm-dd hh24:mi:ss');
  END_DAY_UTC := fun_date2utc(add_months(to_date('2017-01-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),1));
  FOR i in 1..v_2+1
     LOOP
     --ADD_SQL:= 'insert into td_time select sys_guid() ,''c30db8c4211540c3aece140e50a23b7a'', ''' || ADD_START_DAY || ''', ''day'';' ;
     INS_SQL:= 'insert into BAK_TEST2_0608 SELECT
  org.ent_name  ,
  SYS.op_loginname  ,
  fun_name  ,
  COUNT(fun_name),''' || START_DAY_DATE1 || '''
FROM
  TB_ORGANIZATION org
INNER JOIN (
  SELECT
    tg.OP_ID,
    tg.ENT_ID,
    SYS_F.FUN_NAME
  FROM
    TL_OPERATE_LOG tg
  INNER JOIN (
    SELECT
      T.fun_id,
      CONNECT_BY_ROOT T.fun_name fun_name
    FROM
      SYS_FUNCTION T
    WHERE
      T.ENABLE_FLAG != ''0'' START WITH T.fun_id IN (
        ''FG_MEMU_MONITOR'',
        ''FG_MEMU_SAFE'',
        ''FG_MEMU_ENERGY'',
        ''FG_MEMU_MAINTENANCE'',
        ''FG_MEMU_OPERATIONS'',
        ''FG_MEMU_STATIC''
      ) CONNECT BY PRIOR T.fun_id = T.FUN_PARENT_ID
  ) sys_f ON tg.fun_id = SYS_F.FUN_ID
  AND tg.log_utc >= ' || START_DAY_UTC ||'
  AND tg.log_utc < ' || END_DAY_UTC || '
  and length(ENT_ID) <> 25
) tg_info ON org.ent_id = tg_info.ent_id
LEFT JOIN SYS_SP_OPERATOR sys ON tg_info.op_id = sys.op_id
WHERE
  org.ent_name IN (SELECT ent_name FROM temp_org)
GROUP BY
  org.ent_name,
  sys.op_loginname,
  tg_info.fun_name
ORDER BY
  org.ent_name,
  tg_info.fun_name';
    BEGIN
         EXECUTE IMMEDIATE INS_SQL;
         commit;
         sys.DBMS_LOCK.sleep(5);           
    END;  
     --(add_months(to_date(ADD_START_MONTH,'yyyymm'),1),'yyyymm');
     START_DAY_UTC := fun_date2utc(add_months(to_date('2017-01-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),i));
     END_DAY_UTC := fun_date2utc(add_months(to_date('2017-01-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),i+1));
     START_DAY_DATE := add_months(to_date('2017-01-01 00:00:00','yyyy-mm-dd hh24:mi:ss'),i);
     START_DAY_DATE1  := to_char(START_DAY_DATE,'yyyy-mm-dd hh24:mi:ss');
     --START_DAY:=  ((to_date(ADD_START_DAY,'yyyy-mm-dd')+1),'yyyy-mm-dd');
     --END_DAY:=  ((to_date(ADD_START_DAY,'yyyy-mm-dd')+1),'yyyy-mm-dd');
     dbms_output.put_line(INS_SQL);
    end loop;
end;
/

