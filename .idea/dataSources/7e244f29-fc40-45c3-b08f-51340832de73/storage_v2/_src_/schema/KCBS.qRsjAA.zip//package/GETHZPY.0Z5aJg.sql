create package  GetHZPY is

  -- Author  : ADMINISTRATOR
  -- Created : 2006-10-8 上午 11:51:16
  -- Purpose : 获得汉字拼音编码

  -- Public type declarations
  TYPE THZPY_LIST is VARRAY (526) OF  VARCHAR2(6);
  TYPE TROMA_NUM_LIST is VARRAY (94) OF  VARCHAR2(2);
  TYPE TGREECE_ALPHABET_LIST is VARRAY (24) OF  VARCHAR2(2);
  TYPE TPYIndex_191_list IS VARRAY(191) OF NUMBER;
  TYPE TPYIndex_list IS VARRAY(10) OF TPYIndex_191_list;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;

  -- Public function and procedure declarations
  function GetHzPY_by_index(p_PY_Index number) RETURN VARCHAR2;
  FUNCTION get_greece_alphabet_py(p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_roma_num_py(p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_01(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_02(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_03(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_04(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_05(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_06(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_07(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_08(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_09(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_10(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_11(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_12(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION get_py_index_13(p_Index1 NUMBER, p_Index NUMBER) RETURN NUMBER;
  FUNCTION GetHzFullPY(p_String varchar2) RETURN VARCHAR2;
  FUNCTION GetHzPYCAP(p_String varchar2) RETURN VARCHAR2;
end ;
/

