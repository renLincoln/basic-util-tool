create PROCEDURE DEAL_VEHICLE_STATE
AS
   CURSOR RUN_VEHICLE_DATA
   IS
        SELECT *
          FROM (SELECT *
                  FROM ly_vehicle_state
                 WHERE task_end <= FUN_DATE2UTC (SYSDATE) AND status = 2
                UNION
                SELECT *
                  FROM ly_vehicle_state
                 WHERE FUN_DATE2UTC (SYSDATE) >= task_begin AND status = 3)
      ORDER BY operate_time;

   VEH_RECORD   RUN_VEHICLE_DATA%ROWTYPE;
--1、营运中的车辆（状态为2），当任务结束状态更新为待命中
--2、已派车辆任务尚未开始（状态为3），当任务开始状态更新为营运中
BEGIN
   --打开游标
   OPEN RUN_VEHICLE_DATA;

   LOOP
      BEGIN
         FETCH RUN_VEHICLE_DATA INTO VEH_RECORD;

         EXIT WHEN RUN_VEHICLE_DATA%NOTFOUND;

         IF VEH_RECORD.STATUS = 2
         THEN
            UPDATE ly_vehicle_state
               SET STATUS = 1
             WHERE TB_ID = VEH_RECORD.TB_ID;
         ELSIF VEH_RECORD.STATUS = 3
         THEN
            UPDATE ly_vehicle_state
               SET STATUS = 2
             WHERE TB_ID = VEH_RECORD.TB_ID;

            DELETE FROM ly_vehicle_state
                  WHERE STATUS = 1 AND VEHICLE_ID = VEH_RECORD.VEHICLE_ID;
         END IF;

         COMMIT;
      EXCEPTION
         WHEN OTHERS
         THEN
            ROLLBACK;
      END;
   END LOOP;

   CLOSE RUN_VEHICLE_DATA;

   COMMIT;
END DEAL_VEHICLE_STATE;
/

