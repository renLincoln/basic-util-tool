create FUNCTION FUN_GETVEHICLEINFO (orderId in varchar2)
return varchar2 is str varchar2(500);
begin
  for r in (select t.vehicle_code,t.driver,t.phone from Ly_Vehicle_Dispatch t where t.order_id = orderId )
      loop
        str := str || r.vehicle_code || ':'|| r.driver || ':'|| r.phone || ';';
      end loop;
      str:= substr(str,0,length(str)-1);
  return (str);
end fun_getVehicleInfo;
/

