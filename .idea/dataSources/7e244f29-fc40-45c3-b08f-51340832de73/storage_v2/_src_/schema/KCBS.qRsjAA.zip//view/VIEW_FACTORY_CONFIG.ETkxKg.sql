create view VIEW_FACTORY_CONFIG as
  SELECT leaf_id vf_id, vid, '1' control_type
     FROM mv_vehicle
    WHERE tree_type = 5
/

