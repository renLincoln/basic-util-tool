create view MVIEW_ALARM_CONF as
  SELECT DISTINCT o.ENT_ID,
          l.level_code level_code,
          l.level_name,
          i.sys_alarm_type_id alarm_code,
          t.alarm_name,
          c.pop_point,
          c.voice_point,
          c.voice_point_url,
          c.down_point,
          c.MESSAGE,
          c.alarm_show
     FROM tb_alarm_ent_conf c,
          tb_alarm_ent_info i,
          sys_alarm_type t,
          sys_alarm_level l,
          mview_org_map o
    WHERE     c.pid = i.tb_alarm_ent_conf_id
          AND c.ent_id = o.root_id
          AND c.sys_alarm_level_id = l.level_id
          AND i.sys_alarm_type_id = t.alarm_code
/

