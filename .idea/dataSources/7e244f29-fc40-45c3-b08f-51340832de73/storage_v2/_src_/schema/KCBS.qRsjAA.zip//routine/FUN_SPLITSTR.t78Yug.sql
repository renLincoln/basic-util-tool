create FUNCTION "FUN_SPLITSTR" (p_string IN VARCHAR2, p_delimiter IN VARCHAR2)
   RETURN NUMBER
AS
   v_length   NUMBER := LENGTH (p_string);
   v_start    NUMBER := 2;
   v_index    NUMBER;
   v_to       NUMBER := 0;
BEGIN
   WHILE (v_start <= v_length)
   LOOP
      v_index := INSTR (p_string || p_delimiter, p_delimiter, v_start);

      IF v_index = 0
      THEN
         -- v_to := substr(p_string, v_start);
         v_start := v_length + 1;
      ELSE
         v_to :=
            v_to + TO_NUMBER (SUBSTR (p_string, v_start, v_index - v_start));
         v_start := v_index + 1;
      END IF;
   END LOOP;

   RETURN v_to;
END fun_splitstr;
/

