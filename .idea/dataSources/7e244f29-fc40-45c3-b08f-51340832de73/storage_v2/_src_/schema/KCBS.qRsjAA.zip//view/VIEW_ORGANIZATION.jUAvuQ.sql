create view VIEW_ORGANIZATION as
  SELECT o.ent_id,
          o.ent_name,
          o.ent_state,
          o.parent_id,
          (SELECT org.ent_name
             FROM tb_organization org
            WHERE org.ent_id = o.parent_id)
             AS parent_name,
          o.ent_type,
          o.enable_flag,
          o.create_by,
          o.create_time,
          o.update_by,
          o.update_time,
          c.corp_level,
          c.corp_code,
          c.org_shortname,
          c.isdeteam,
          c.org_cphone,
          c.corp_country,
          c.corp_province,
          c.corp_city,
          c.corp_businessno,
          c.special_id,
          c.business_scope,
          c.certificate_office,
          c.licence_no,
          c.licence_word,
          c.corp_quale,
          c.corp_boss,
          c.corp_paystate,
          c.corp_paytype,
          c.corp_economytype,
          c.org_address,
          c.org_czip,
          c.org_cfax,
          c.url,
          c.org_cmail,
          c.org_cname,
          c.org_cno,
          c.org_logo,
          c.org_mem,
          c.business_license,
          o.seq_code,
          o.iscompany,
          o.groups_billing_code,
          o.ent_english_name,
          o.main_phone,
          o.customer_manager_name,
          o.customer_manager_phone,
          o.group_state,
          --o.validate_flag,
          (SELECT op.op_name
             FROM SYS_SP_OPERATOR op
            WHERE op.op_id = o.create_by)
             AS CREATE_BY_NAME,
          (SELECT op.op_name
             FROM SYS_SP_OPERATOR op
            WHERE op.op_id = o.update_by)
             AS UPDATE_BY_NAME,
             c.PLATFORM_UNIQUE_CODE,
             c.LICENCE_START_TIME,
             c.LICENCE_END_TIME,
						 o.BILLING_TYPE,
						 o.AFFILIATED_BRANCH,
						 o.AFFILIATED_BRANCH_ID
     FROM TB_ORGANIZATION o, TB_ORG_INFO c
    WHERE o.ent_id = c.ent_id AND o.enable_flag != 0
/

