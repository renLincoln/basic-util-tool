create materialized view MVIEW_ORG_MAP
refresh force on demand
  as
    WITH mid1
     AS                                                     --获取全量组织表由父到子的递归结果
       (    SELECT a.ent_id,
                   a.parent_id,
                   LEVEL lvl,
                   CONNECT_BY_ROOT (ent_id) root_id
              FROM tb_organization a
             WHERE a.enable_flag = '1'
        CONNECT BY PRIOR ent_id = parent_id
        START WITH ent_id IN (SELECT DISTINCT ent_id FROM tb_alarm_ent_conf)),
     mid2
     AS (  SELECT ent_id, MIN (lvl) lvl
             FROM mid1 m
         GROUP BY ent_id)                                        --以最下级企业的设置为准
SELECT o.ent_id, DECODE (a.ent_id, NULL, 0, a.root_id) root_id --没有设置过告警等级的企业以默认值为准，默认值的ent_id在tb_alarm_ent_conf表中为0
  FROM tb_organization o,
       (SELECT m1.ent_id, root_id
          FROM mid1 m1, mid2 m2
         WHERE m1.ent_id = m2.ent_id AND m1.lvl = m2.lvl) a
 WHERE o.ent_id = a.ent_id(+) AND o.enable_flag = '1'
/

