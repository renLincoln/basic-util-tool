create view VIEW_VEHICLE_STAFF_ORG as
  SELECT E.STAFF_ID,
          E.STAFF_NAME,
          O.ENT_NAME,
          O.ENT_ID,
          PO.ENT_NAME PARENT_ENT_NAME,
          PO.ENT_ID PARENT_ENT_ID,
          E.SEX,
          E.MOBILEPHONE,
          E.ADDRESS,
          E.DRIVER_NO,
          E.ARCHIVENO,
          S.VEHIVLENO,
          S.VID,
          E.UPDATE_TIME,
          E.CARD_ID,
          E.BUSSINESS_ID,
          E.DRIVERCARD_DEP,
          E.DRIVER_ICCARD,
          CDS.CARDID,
          CDS.CARD_NO,
          E.DRIVER_VALDATE,
          E.DRIVER_CHDATE,
          E.QUASI_DRIVING_TYPE,
          E.DRIVER_TIP_DAYS,
          E.BUSSINESS_VALDATE,
          E.BUSSINESS_TIP_DATYS,
          E.DRIVER_NO,
          E.DRIVING_PERMITS,
          E.Staff_State
     FROM TB_EMPLOYEE E
          LEFT JOIN TB_ORGANIZATION O
             ON E.ENT_ID = O.ENT_ID
          LEFT JOIN TB_ORGANIZATION PO
             ON O.PARENT_ID = PO.ENT_ID
          LEFT JOIN (  SELECT SS.STAFF_ID AS STAFF_ID,
                              WM_CONCAT (VV.VEHICLE_NO) AS VEHIVLENO,
                              WM_CONCAT (VV.VID) AS VID
                         FROM TR_VEHICLE_STAFF SS, TB_VEHICLE VV
                        WHERE SS.VID = VV.VID AND VV.ENABLE_FLAG = '1'
                     GROUP BY SS.STAFF_ID) S
             ON E.STAFF_ID = S.STAFF_ID
          LEFT JOIN (SELECT C.CARDID, C.STAFF_ID, D.CARD_NO
                       FROM TR_ICCARD_STAFF C, TB_IC_CARD D
                      WHERE     D.ICID = C.CARDID
                            AND D.CARD_STATE = '2'
                            AND C.ENABLE_FLAG = 1) CDS
             ON E.STAFF_ID = CDS.STAFF_ID
    WHERE E.ENABLE_FLAG = 1
/

