create PROCEDURE DEAL_ORDER_STATE
AS
   CURSOR RUN_ORDER_DATA
   IS
      SELECT *
        FROM ly_order
       WHERE     status = 5
             AND end_time <= fun_date2utc (SYSDATE)
             AND enable_flag = 1;

   ORDER_RECORD   RUN_ORDER_DATA%ROWTYPE;
BEGIN
   --打开游标
   OPEN RUN_ORDER_DATA;

   LOOP
      BEGIN
         FETCH RUN_ORDER_DATA INTO ORDER_RECORD;

         EXIT WHEN RUN_ORDER_DATA%NOTFOUND;

         --将状态为调度待收车(5)更新为已收车待报账(6),同时更新车辆调度表为状态为已收车待报账
         UPDATE ly_order
            SET status = 6
          WHERE tb_id = ORDER_RECORD.TB_ID AND status = 5;

         UPDATE ly_vehicle_dispatch t
            SET t.vehicle_status = 2
          WHERE t.order_id = ORDER_RECORD.TB_ID AND t.vehicle_status = 1;
      EXCEPTION
         WHEN OTHERS
         THEN
            ROLLBACK;
      END;
   END LOOP;

   CLOSE RUN_ORDER_DATA;

   COMMIT;
END DEAL_ORDER_STATE;
/

